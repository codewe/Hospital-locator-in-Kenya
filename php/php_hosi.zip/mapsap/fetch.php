<?php
include_once 'selectedhospitals.php';
//$selectedHos = new SelecteHospitals();
//echo "hello";
if(isset($_GET['sid'])){
	switch($_GET['sid']){
		//login
		case 1:
                   //$hosid = $_GET['hos_id'];
                   $selectedHos = new SelectedHospitals();
                   echo $selectedHos->getCounties();
                
			break;
                case 2:
                   //$hosid = $_GET['hos_id'];
                   $selectedHos = new SelectedHospitals();
                   echo $selectedHos->getAllHospitals();
                
			break;
                case 3:
                     if(isset($_GET['county_id'])){
                        $county_id = $_GET['county_id'];
                        $selectedHos = new SelectedHospitals();
                        echo $selectedHos->getCountyHospitals($county_id);
                      }else{
                        echo "Please provide county id";
                      }
                        break;
		case 4:
                     if(isset($_GET['lati']) AND isset($_GET['longi'])){
                        $lat = $_GET['lati'];
                        $long=$_GET['longi'];
                        $selectedHos = new SelectedHospitals();
                        echo $selectedHos->getLocationHospitals($lat,$long);
                      }else{
                        echo "Please provide latitude id and longitude id";
                      }
                        break;
                case 5:
                       if(isset($_POST['usermail']) AND isset($_POST['feedback'])){
                        $usermail = $_POST['usermail'];
                        $feedback=$_POST['feedback'];
                        $selectedHos = new SelectedHospitals();
                        echo $selectedHos->AddFeedback($usermail,$feedback);
                      }else{
                        echo "Please provide usermail and feedback";
                      }
                        break;
		default:
			echo 'UNKNOWN REQUEST';		
	}
}else{
	echo 'ERROR 100: Invalid request. Please provide service ID';
}

?>