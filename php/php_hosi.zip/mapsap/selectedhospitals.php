<?php
include_once 'database.php';

//a class to handle database operations
class SelectedHospitals{ 
    private $db, $dbcon, $response, $queryStatus;
 
    public function __construct(){             
    $this->dbcon = new DBConnection();
    $this->db = $this->dbcon->connect();
    }   
    //selects and returns specific hospital details
     public function getCounties(){
        $stmt = $this->db->prepare("SELECT * FROM counties");
        $this->queryStatus = $stmt->execute();
                if($this->queryStatus){
                    $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    $this->response = array();
                    $this->response["counties"] = array();
                    $this->response["counties"] = $resultSet;
                    $this->response["status"] = "1";
                }else{
                    $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
     }
     public function getAllHospitals(){
        $stmt=$this->db->prepare("SELECT * FROM hospitals");
        $this->queryStatus = $stmt->execute();
                if($this->queryStatus){
                     $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                     $this->response = array();
                     $this->response["hospitals"] = array();
                     $this->response["hospitals"] = $resultSet;
                     $this->response["status"] = "1";
                }else{
                     $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
     }
     public function getCountyHospitals($county_id){
        $stmt=$this->db->prepare("SELECT * FROM hospitals WHERE countyid = :countyid");
        $this->queryStatus = $stmt->execute(array(':countyid' => $county_id));
                if($this->queryStatus){
                     $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                     $this->response = array();
                     $this->response["hospitals"] = array();
                     $this->response["hospitals"] = $resultSet;
                     $this->response["status"] = "1";
                }else{
                     $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
     }
    public function getLocationHospitals($lat, $long){
        $stmt=$this->db->prepare("SELECT * FROM hospitals WHERE latitude = :latitude AND longitude = :longitude");
        $this->queryStatus = $stmt->execute(array(':latitude' => $lat,':longitude' => $long));
                if($this->queryStatus){
                     $resultSet = $stmt->fetchAll(PDO::FETCH_ASSOC);
                     $this->response = array();
                     $this->response["locationhospitals"] = array();
                     $this->response["locationhospitals"] = $resultSet;
                     $this->response["status"] = "1";
                }else{
                     $this->response["status"] = "0";
                }
                
                return json_encode($this->response);
     } 
    public function AddFeedback($usermail, $feedback){
    
        $stmt = $this->db->prepare("INSERT INTO feedback(sendermail, feedback)
                    VALUES(:sendermail, :feedback)");
        $this->$queryStatus = $stmt->execute(array(":sendermail"=>$usermail,  ":feedback"=>$feedback)); 
        if($this->queryStatus){
             $this->response = array();
             $this->response["status"] = "1";
        }else{
            $this->response["status"] = "0";
        }
        return json_encode($this->response);
    }
    
}
?>