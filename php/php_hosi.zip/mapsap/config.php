<?php
/**
 * Database configuration
 */
define('DB_USERNAME', 'your db username');
define('DB_PASSWORD', 'your db password');
define('DB_HOST', 'localhost');
define('DB_NAME', 'your db name');

?>
