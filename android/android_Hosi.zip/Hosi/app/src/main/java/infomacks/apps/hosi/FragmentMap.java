package infomacks.apps.hosi;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.InflateException;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;

import infomacks.apps.hosi.handler.ServiceHandler;

import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_HYBRID;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_NORMAL;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_SATELLITE;
import static com.google.android.gms.maps.GoogleMap.MAP_TYPE_TERRAIN;

public class FragmentMap extends Fragment {
    private LocationManager locationManager;
    Location location;
    public static GoogleMap mMap;
    private boolean isGPSEnabled;
    // Getting reference to radio group
    private LatLng hospitalCoordinates, currentLocation;
    private RadioGroup rgViews;
    private static View rootView;
//    private static ArrayList<HashMap<String, String>> hospitalDetails;
    private ProgressDialog pDialog;
    // JSON Response node names
    private static String KEY_SUCCESS = "status";
    public static final String TAG_HOSPITALS = "hospitals", TAG_NAME = "hospitalname",
            TAG_ID = "hospitalid", TAG_LEVEL = "levelid", TAG_LAT = "latitude", TAG_LONG = "longitude",
            TAG_COUNTY = "countyid";

    JSONArray hospitals = null;
    // Hashmap for ListView
    ArrayList<HashMap<String, String>> hospitalDetails;
//    private static String url = "http://eliteinnovations.biz/mapsap/fetch.php?sid=2";
    private static String url;

    private TextView anotherLabel, level;
    private static int selectedCountyID;
    // Alert Dialog Manager
    AlertDialogManager alert = new AlertDialogManager();
    public static FragmentMap newInstance(int countyID) {
        selectedCountyID = countyID;
        return new FragmentMap();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (rootView != null) {
            ViewGroup parent = (ViewGroup) rootView.getParent();
            if (parent != null)
                parent.removeView(rootView);
        }
        try {
            rootView = inflater.inflate(R.layout.fragment_map, container, false);
        } catch (InflateException e) {
            /* map is already there, just return view as it is */
        }

        if(selectedCountyID != 0){
            url = "http://eliteinnovations.biz/mapsap/fetch.php?sid=3&county_id="+selectedCountyID;
        }else{
            url = "http://eliteinnovations.biz/mapsap/fetch.php?sid=2";
        }
        checkGPSAndGetCurrentLatLong();
        //initialize radio buttons for changing map type
        rgViews = (RadioGroup) rootView.findViewById(R.id.radio_group_list_selector);
        //intialize arraylist to store hospital data
        hospitalDetails = new ArrayList<HashMap<String,String>>();
        //setup map
        new GetAllHospitals().execute();
        return rootView;
    }
    private void checkGPSAndGetCurrentLatLong() {
        if (!isGPSEnabled) {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());

            // Setting Dialog Title
            alertDialog.setTitle("GPS settings");

            // Setting Dialog Message
            alertDialog.setMessage("GPS is not enabled. Do you want to go to settings menu?");

            // On pressing Settings button
            alertDialog.setPositiveButton("Settings", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);
                }
            });

            // on pressing cancel button
            alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.cancel();
                }
            });

            // Showing Alert Message
            alertDialog.show();

        }
    }


    private void setupHospitalMap(ArrayList<HashMap<String, String>> details) {
        Marker currentMarker = null;
        if (mMap == null || mMap != null) {
            mMap = ((MapFragment) getActivity().getFragmentManager()
                    .findFragmentById(R.id.map)).getMap();
            // Add a marker in Nairobi and move the camera
            for (int i = 0; i < details.size(); i++) {
                String hospitalLatitude = details.get(i).get(TAG_LAT),
                        hospitalLongitude = details.get(i).get(TAG_LONG),
                        name = details.get(i).get(TAG_NAME),
                        levelid = details.get(i).get(TAG_LEVEL), address = "", levelname = "";
                hospitalCoordinates = new LatLng(Double.parseDouble(hospitalLatitude), Double.parseDouble(hospitalLongitude));
                MarkerOptions markerOptions = new MarkerOptions().position(hospitalCoordinates);
                try {
                    address = new Geocoder(getActivity(), Locale.getDefault()).
                            getFromLocation(Double.parseDouble(hospitalLatitude), Double.parseDouble(hospitalLongitude), 1).
                            get(0).getAddressLine(0);
                } catch (IOException e) {
                    e.printStackTrace();
                }catch (IndexOutOfBoundsException indexEXP){
                    address = "Unknown";
                }
                switch (Integer.parseInt(levelid)){
                    case 1:
                        levelname = "Community Hospital";
                        break;
                    case 2:
                        levelname = "Dispensary";
                        break;
                    case 3:
                        levelname = "Health Centre";
                        break;
                    case 4:
                        levelname = "District/Sub—District Hospital";
                        break;
                    case 5:
                        levelname = "Provincial hospital";
                        break;
                    case 6:
                        levelname = "National Referral Hospital";
                        break;
                    case 7:
                        levelname = "Private";
                        break;

                }
                name = name + "#" + address + "#"+ levelname;
                markerOptions.title(name);

                switch (Integer.parseInt(levelid)){
                    case 1:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level1));
                        break;
                    case 2:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level2));
                        break;
                    case 3:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level3));
                        break;
                    case 4:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level4));
                        break;
                    case 5:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level5));
                        break;
                    case 6:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level6));
                        break;
                    case 7:
                        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.mipmap.level7));
                        break;
                }

                currentMarker = mMap.addMarker(markerOptions);
            }

            //last hospital in the list
            currentLocation = hospitalCoordinates;

            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setZoomControlsEnabled(true);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(currentLocation));
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLocation, 8));

            mMap.setInfoWindowAdapter(new MarkerInfoWindowAdapter());

            mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
                @Override
                public boolean onMarkerClick(com.google.android.gms.maps.model.Marker marker) {
                    marker.showInfoWindow();
                    return true;
                }
            });

            mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
                @Override
                public void onInfoWindowClick(Marker marker) {
                    Intent hosiDetails = new Intent(getActivity().getApplicationContext(), HospitalDetail.class);
                    hosiDetails.putExtra(HospitalDetail.EXTRA_NAME, marker.getTitle().toString());
                    hosiDetails.putExtra("location", anotherLabel.getText());
                    hosiDetails.putExtra("level", level.getText());
                    getActivity().startActivity(hosiDetails);
                }
            });

            // Defining Checked Change Listener for the RadioGroup
            RadioGroup.OnCheckedChangeListener checkedChangeListener = new RadioGroup.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(RadioGroup group, int checkedId) {
                    if (checkedId == R.id.normal) {
                        mMap.setMapType(MAP_TYPE_NORMAL);
                    }
                    // Currently checked is rb_map
                    else if (checkedId == R.id.satellite) {
                        mMap.setMapType(MAP_TYPE_SATELLITE);
                    }

                    // Currently checked is rb_satellite
                    else if (checkedId == R.id.hybrid) {
                        mMap.setMapType(MAP_TYPE_HYBRID);
                    } else if (checkedId == R.id.terrain) {
                        mMap.setMapType(MAP_TYPE_TERRAIN);
                    }
                }
            };
            // Setting Checked ChangeListener
            if (mMap != null) {
                rgViews.setOnCheckedChangeListener(checkedChangeListener);
            }
            currentMarker.showInfoWindow();
            // Dismiss the progress dialog
            if (pDialog.isShowing()){
                pDialog.dismiss();
            }
        }
    }

    public class MarkerInfoWindowAdapter implements GoogleMap.InfoWindowAdapter
    {
        public MarkerInfoWindowAdapter()
        {
        }

        @Override
        public View getInfoWindow(Marker marker)
        {
            return null;
        }

        @Override
        public View getInfoContents(final Marker marker)
        {
            View v  = getActivity().getLayoutInflater().inflate(R.layout.mapinfowindow, null);

//            MyMarker myMarker = mMarkersHashMap.get(marker);

            ImageView markerIcon = (ImageView) v.findViewById(R.id.marker_icon);

            TextView markerLabel = (TextView)v.findViewById(R.id.marker_label);

            anotherLabel = (TextView)v.findViewById(R.id.another_label);
            level = (TextView)v.findViewById(R.id.updatetime);
            Button moreDetails = (Button) v.findViewById(R.id.moreDetails);

            try {
                markerIcon.setImageResource(R.mipmap.ic_launcher);
                markerLabel.setText(marker.getTitle().split("#")[0]);
            }catch (NullPointerException exp){
                markerIcon.setImageResource(R.mipmap.ic_launcher);
                markerLabel.setText("Hospital");
            }
            anotherLabel.setText("Location: "+marker.getTitle().split("#")[1]);
            level.setText(marker.getTitle().split("#")[2]);

            return v;
        }
    }

    /**
     * Async task class to get json by making HTTP call
     * */
    private class GetAllHospitals extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(getActivity());
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();
            String id, name, latitude, longitude, level, county;
            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            //shows the response that we got from the http request on the logcat
            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
                    final JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node for the object we called student
                    hospitals = jsonObj.getJSONArray(TAG_HOSPITALS);

                    if(Integer.parseInt(jsonObj.getString(KEY_SUCCESS)) != 0) {
                        // looping through All Contacts
                        for (int i = 0; i < hospitals.length(); i++) {
                            JSONObject s = hospitals.getJSONObject(i);

                            id = s.getString(TAG_ID);
                            name = s.getString(TAG_NAME);
                            latitude = s.getString(TAG_LAT);
                            longitude = s.getString(TAG_LONG);
                            county = s.getString(TAG_COUNTY);
                            level = s.getString(TAG_LEVEL);

                            // tmp hashmap for single hospital
                            HashMap<String, String> hosi = new HashMap<String, String>();

                            // adding each child node to HashMap key => value
                            hosi.put(TAG_ID, id);
                            hosi.put(TAG_NAME, name);
                            hosi.put(TAG_LAT, latitude);
                            hosi.put(TAG_LONG, longitude);
                            hosi.put(TAG_COUNTY, county);
                            hosi.put(TAG_LEVEL, level);

                            // adding hosi to hosi list
                            hospitalDetails.add(hosi);
                        }
                    }else{
                        //no malls found
                        getActivity().runOnUiThread(new Runnable() {

                            @Override
                            public void run() {
                                // loginErrorMsg.setText("Incorrect PhoneNumber/Password");
                                try {
                                    alert.showAlertDialog(
                                            getActivity(),
                                            "Service response",
                                            jsonObj.getString("message"),
                                            false);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                                pDialog.dismiss();
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
                //no malls found
                getActivity().runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        alert.showAlertDialog(
                                getActivity(),
                                "Service response",
                                "No records found",
                                false);
                        pDialog.dismiss();
                    }
                });
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            setupHospitalMap(hospitalDetails);
        }

    }
}
